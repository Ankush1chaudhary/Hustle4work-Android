package com.example.hustle4work.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import android.widget.TextView;
import android.widget.Toast;

import com.example.hustle4work.R;
import com.example.hustle4work.utility.CSPreferences;
import com.example.hustle4work.utility.WebApiCall;

public class LoginActivity extends AppCompatActivity {


    EditText editTextUsername ,editTxtPassword;
    TextView txtSignUp, btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);
        editTextUsername = findViewById(R.id.editEmail);
        editTxtPassword = findViewById(R.id.editpasswd);
        txtSignUp = findViewById(R.id.txtSignUp);
        btnLogin =findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateFields();
            }
        });



        txtSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(i);
            }
        });
    }

    private void validateFields() {
        String username = editTextUsername.getText().toString();
        String password = editTxtPassword.getText().toString();



        if (username.isEmpty() || password.isEmpty()) {
            showToast("Username and password are required");
        } else {
            CSPreferences.clearPref(this);
            WebApiCall webApiCall = new WebApiCall(LoginActivity.this);
            webApiCall.login(username,password);
        }//q@gamil.com
    }

    private void showToast(String message) {
        Toast.makeText(LoginActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}