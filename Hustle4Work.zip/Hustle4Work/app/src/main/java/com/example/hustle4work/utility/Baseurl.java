package com.example.hustle4work.utility;

public class Baseurl {
    //https://f8a6-2607-fea8-e80-280-90f3-299c-4042-8713.ngrok.io
    public static final String BASE_URL = "https://hustle4work-nyp0.onrender.com";
}
