package com.example.hustle4work.model;

public class JobDetails {
    private String title;
    private String desc;
    private String loc;
    private String req;
    private String pay;
    private String jobType;

    public JobDetails(String title, String desc, String loc, String req, String pay, String jobType) {
        this.title = title;
        this.desc = desc;
        this.loc = loc;
        this.req = req;
        this.pay = pay;
        this.jobType = jobType;
    }

    // Getters and Setters for each field
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getLoc() {
        return loc;
    }

    public void setLoc(String loc) {
        this.loc = loc;
    }

    public String getReq() {
        return req;
    }

    public void setReq(String req) {
        this.req = req;
    }

    public String getPay() {
        return pay;
    }

    public void setPay(String pay) {
        this.pay = pay;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }
}

