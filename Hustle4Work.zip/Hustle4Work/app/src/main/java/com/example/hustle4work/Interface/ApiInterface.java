package com.example.hustle4work.Interface;

import com.example.hustle4work.model.JobDetails;
import com.example.hustle4work.model.JobFeed;
import com.example.hustle4work.model.SignInRequest;
import com.example.hustle4work.model.SignUpResponse;
import com.example.hustle4work.model.UserInformation;
import com.example.hustle4work.model.UserReponse_1;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface ApiInterface {

    @FormUrlEncoded
    @POST("signup")
    Call<SignUpResponse> signUp(@FieldMap Map<String, String> params);

  /*  @FormUrlEncoded
    @POST("signin")
    Call<UserReponse_1> signIn(@FieldMap Map<String, String> params);*/

    @POST("users/signin")
    Call<UserReponse_1> signIn(@Body SignInRequest signInRequest);

  /*  @GET("jobs") // Update with your actual endpoint
    Call<JobFeed> getJobs(@QueryMap Map<String, String> options);*/

  /*  @GET("jobs")
    Call<JobFeed> getJobs(@Body feedPassparams feedPassparams);
*/
  @GET("jobs")
  Call<List<JobFeed>> getJobs(
            @Query("username") String username,
            @Query("email") String email,
            @Query("phoneNumber") String phoneNumber,
            @Query("address") String address,
            @Query("qualification") String qualification,
            @Query("skills") String skills,
            @Query("experience") String experience
    );

    @POST("userData/createUserData/")
    Call<UserInformation> userInfor(@Body UserInformation UserInformation);

    @FormUrlEncoded
    @POST("createJob")
    Call<JobDetails> jobDetails(@FieldMap Map<String, String> params);

}
