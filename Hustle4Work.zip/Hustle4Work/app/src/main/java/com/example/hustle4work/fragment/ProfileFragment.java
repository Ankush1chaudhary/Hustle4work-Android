package com.example.hustle4work.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.hustle4work.R;

import org.w3c.dom.Text;

public class ProfileFragment extends Fragment {

   View  view;

   ImageView iv_back;
   TextView profile ,btnSave ;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.activity_seeker_form, container, false);;

        iv_back = view.findViewById(R.id.iv_back);
        profile = view.findViewById(R.id.profile);
        btnSave = view.findViewById(R.id.btnSave);

        profile.setText("Profile");
        iv_back.setVisibility(View.INVISIBLE);
        btnSave.setText("Update");

        return view;
    }
}