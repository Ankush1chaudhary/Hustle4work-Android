package com.example.hustle4work.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import com.example.hustle4work.R;
import com.example.hustle4work.fragment.JobsFeed;
import com.example.hustle4work.fragment.ProfileFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    FragmentManager fm;
    FragmentTransaction fragmentTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        loadFragment("Fragment1");

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);

// Assume initially the first item is selected
        final boolean[] isFirstItemSelected = {true};

        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.job) {
                // Check if the second item is selected
                if (!isFirstItemSelected[0]) {
                    loadFragment("Fragment1");
                    // Do something when the second item is unselected
                    // For example:
                    // performActionWhenSecondItemUnselected();
                }
                isFirstItemSelected[0] = true; // Set the flag to the first item selected
            } else if (itemId == R.id.profile) {
                // Check if the first item is selected
                if (isFirstItemSelected[0]) {
                    loadFragment("Fragment2");
                    // Do something when the f
                    // irst item is unselected
                    // For example:
                    // performActionWhenFirstItemUnselected();
                }
                isFirstItemSelected[0] = false; // Set the flag to the second item selected
            }

            return true;
        });


    }

    private void loadFragment(String fragmentName) {
        Fragment fragment = null;

        switch (fragmentName) {
            case "Fragment1":
                fragment = new JobsFeed();
                break;
            case "Fragment2":
                fragment = new ProfileFragment();
                break;

        }

        if (fragment != null) {
            startFragmentTransaction(fragment);
        }
    }

    private void startFragmentTransaction(Fragment fragment) {
        fm = getSupportFragmentManager();
        fragmentTransaction = fm.beginTransaction();
        fragmentTransaction.replace(R.id.frameLayout, fragment);
        fragmentTransaction.addToBackStack(null); // If you want to add the fragments to the back stack
        fragmentTransaction.commit();
    }

}