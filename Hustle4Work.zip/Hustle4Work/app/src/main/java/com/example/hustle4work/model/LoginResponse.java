package com.example.hustle4work.model;

public class LoginResponse {
    private String username;
    private String password;
    private String token;

    private String message;


    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    // Constructor
    public LoginResponse(String username, String password , String token, String message) {
        this.username = username;
        this.password = password;
        this.token = token;
        this.message = message;
    }

    // Getter for username
    public String getUsername() {
        return username;
    }

    // Setter for username
    public void setUsername(String username) {
        this.username = username;
    }

    // Getter for password
    public String getPassword() {
        return password;
    }

    // Setter for password
    public void setPassword(String password) {
        this.password = password;
    }
}
