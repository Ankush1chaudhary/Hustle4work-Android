package com.example.hustle4work.activity;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hustle4work.R;
import com.example.hustle4work.utility.WebApiCall;

import java.util.Arrays;
import java.util.List;

public class SeekerForm extends AppCompatActivity {


    EditText editUser , editemail ,editphone ,editaddress ,editEduaction ,editSkills ,editexperi;
    TextView btnSave;
       @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seeker_form);
        editUser = findViewById(R.id.editUser);

        editemail = findViewById(R.id.editEmail);
        editphone = findViewById(R.id.editphone);
        editaddress = findViewById(R.id.editaddress);
        editEduaction = findViewById(R.id.editEdu);
        editSkills = findViewById(R.id.editSkil);
        editexperi = findViewById(R.id.editexperi);
           btnSave = findViewById(R.id.btnSave);

           btnSave.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   validateFields();
               }
           });

    }

    private void validateFields() {
        boolean isValid = true;


        String username = editUser.getText().toString();
        String email = editemail.getText().toString();
        String phoneNumber = editphone.getText().toString();
        String address = editaddress.getText().toString();
        String education = editEduaction.getText().toString();
        String skills = editSkills.getText().toString();
        String experience = editexperi.getText().toString();

        List<String> skillsList = Arrays.asList(skills.split(","));
        List<String> experienceList = Arrays.asList(experience.split(","));

        if (username.isEmpty()) {
            showToast("Please enter a username");
            isValid = false;
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showToast("Please enter a valid email address");
            isValid = false;
        }

        if (phoneNumber.isEmpty() || phoneNumber.length() < 10) {
            showToast("Please enter a valid phone number");
            isValid = false;
        }

        if (address.isEmpty()) {
            showToast("Please enter an address");
            isValid = false;
        }

        if (education.isEmpty()) {
            showToast("Please enter education details");
            isValid = false;
        }

        if (skillsList.isEmpty()) {
            showToast("Please enter skills information");
            isValid = false;
        }

        if (experienceList.isEmpty()) {
            showToast("Please enter experience details");
            isValid = false;
        }

        if (isValid) {
            callSeekerApi(username, email, phoneNumber, address, education ,skillsList,experienceList);
        }
    }

    private void callSeekerApi(String username, String email, String phoneNumber, String address, String education , List<String> skills,List<String> experienceList) {

        WebApiCall webApiCall = new WebApiCall(SeekerForm.this);
        webApiCall.SeekerForm(username, email, phoneNumber, address ,education ,skills ,experienceList);


    }


    private void showToast(String message) {
        Toast.makeText(SeekerForm.this, message, Toast.LENGTH_SHORT).show();
    }
}