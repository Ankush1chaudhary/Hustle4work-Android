package com.example.hustle4work.utility;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.hustle4work.Interface.ApiInterface;
import com.example.hustle4work.Interface.JobFeedCallback;
import com.example.hustle4work.activity.MainActivity;
import com.example.hustle4work.activity.SeekerForm;
import com.example.hustle4work.model.JobDetails;
import com.example.hustle4work.model.JobFeed;
import com.example.hustle4work.model.LoginResponse;
import com.example.hustle4work.model.SignInRequest;
import com.example.hustle4work.model.SignUpResponse;
import com.example.hustle4work.model.UserInformation;
import com.example.hustle4work.model.UserReponse_1;
import com.example.hustle4work.model.feedPassparams;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kotlinx.coroutines.Job;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class WebApiCall {

    ApiInterface webApiInterface;
    Context context;
    //CustomProgressDialog customProgressDialog;
    Gson gson;
    private String baseUrl;
    private String from;





    public WebApiCall(Context context) {
        this.context = context;
       // customProgressDialog = new CustomProgressDialog(context);
        this.from = from;

        this.context = context;


        String baseUrl = Baseurl.BASE_URL;
        Gson gson = new GsonBuilder().setLenient().create();

        String authToken = CSPreferences.readString(context, "token");

        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();

        // Create an interceptor to add the token to the headers if it exists
        if (!authToken.isEmpty()) {
            Interceptor headerInterceptor = chain -> {
                Request request = chain.request().newBuilder()
                        .addHeader("Authorization", "Bearer " + authToken)
                        .build();
                return chain.proceed(request);
            };
            httpClient.addInterceptor(headerInterceptor);
        }

        // Add logging interceptor
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        httpClient.addInterceptor(interceptor);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(httpClient.build())
                .build();

        webApiInterface = retrofit.create(ApiInterface.class);

        //customProgressDialog = new CustomProgressDialog(context);
      /*  this.from = from;
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient defaultHttpClient = new OkHttpClient.Builder().addInterceptor(interceptor).build();

        baseUrl = Baseurl.BASE_URL;
        gson = new GsonBuilder().setLenient().create();
        Retrofit retrofit = new Retrofit.Builder().baseUrl(baseUrl).addConverterFactory(GsonConverterFactory.create(gson))
                .client(defaultHttpClient).build();
        webApiInterface = retrofit.create(ApiInterface.class);
*/
    }



    public void registerUser(String username, String email, String password, String phoneNumber, String address) {




        Map<String, String> params = new HashMap<>();
        params.put("email", email);
        params.put("password", password);
        params.put("username", username);
        params.put("address", address);
        params.put("phonenumber", phoneNumber);

        Log.i("baseUrl",""+baseUrl);




        Call<SignUpResponse> signup_Service = webApiInterface.signUp(params);

        signup_Service.enqueue(new Callback<SignUpResponse>() {
            @Override
            public void onResponse(Call<SignUpResponse> call, Response<SignUpResponse> response) {

                showToast("Sucessfully Register.");
            }

            @Override
            public void onFailure(Call<SignUpResponse> call, Throwable t) {
                showToast("Not Register.");
            }

        });
    }

    public void SeekerForm(String username, String email, String phoneNumber, String address, String education, List<String> skills, List<String> experience) {


        UserInformation userInfo = new UserInformation(username, email,phoneNumber,  address,  education,  skills,  experience );

       /*     Map<String, String> params = new HashMap<>();
        params.put("username", username);
        params.put("email", email);
        params.put("phoneNumber", phoneNumber);
        params.put("address", address);
        params.put("qualification", education);
        params.put("skills", skills);
        params.put("experience", experience);*/


        Log.i("baseUrl",""+baseUrl);



        Call<UserInformation> signup_Service = webApiInterface.userInfor(userInfo);

        signup_Service.enqueue(new Callback<UserInformation>() {
            @Override
            public void onResponse(Call<UserInformation> call, Response<UserInformation> response) {

                if (response.isSuccessful()) {

                    UserInformation userResponse = response.body();



                    //  LoginResponse user = userResponse.getUser();
                    // String token = userResponse.getToken();
                    //  CSPreferences.putString(context,"token" ,token);
                    Intent i = new Intent(context, MainActivity.class);
                    context.startActivity(i);





                }

                showToast("Sucessfully Data Save.");
            }

            @Override
            public void onFailure(Call<UserInformation> call, Throwable t) {
                showToast("Not Register.");
            }

        });
    }

    public void EmployerForm(String title, String desc, String loc, String req, String pay, String jobType, String currentDate) {



        Map<String, String> params = new HashMap<>();
        params.put("title", title);
        params.put("description", desc);
        params.put("location", loc);
        params.put("requirements", req);
        params.put("payRate", pay);
        params.put("jobType", jobType);
        params.put("uploadDate", currentDate);



        Log.i("baseUrl",""+baseUrl);


        Call<JobDetails> signup_Service = webApiInterface.jobDetails(params);

        signup_Service.enqueue(new Callback<JobDetails>() {
            @Override
            public void onResponse(Call<JobDetails> call, Response<JobDetails> response) {
                JobDetails jobDetails =  response.body();
                showToast("Sucessfully Register.");
            }

            @Override
            public void onFailure(Call<JobDetails> call, Throwable t) {
                showToast("Not Register.");
            }

        });
    }

    public void login(String email, String password){

    /*    Map<String, String> params = new HashMap<>();
        params.put("email", email);
        params.put("password", password);*/

        SignInRequest signInRequest = new SignInRequest(email, password);


        Log.i("baseUrl",""+baseUrl);



        Call<UserReponse_1> signinservice = webApiInterface.signIn(signInRequest);

        signinservice.enqueue(new Callback<UserReponse_1>() {
            @Override
            public void onResponse(Call<UserReponse_1> call, Response<UserReponse_1> response) {
               // showToast("User not found!");

                if (response.isSuccessful()) {

                    UserReponse_1 userResponse = response.body();

                        LoginResponse user = userResponse.getUser();
                        String token = userResponse.getToken();
                        CSPreferences.putString(context,"token" ,token);
                        Intent i = new Intent(context, SeekerForm.class);
                        context.startActivity(i);





                } else {
                    // Handle unsuccessful response
                }


            }

            @Override
            public void onFailure(Call<UserReponse_1> call, Throwable t) {
                showToast("Not Working");
            }
        });




    }

    public void getjobFeed(String username, String email, String phoneNumber, String address, String qualification, String skills, String experience , JobFeedCallback callback){

    /*    Map<String, String> params = new HashMap<>();
        params.put("email", email);
        params.put("password", password);*/

        //feedPassparams passparams = new feedPassparams(username, email ,phoneNumber ,address,qualification,skills,experience);
        Map<String, String> options = new HashMap<>();
        options.put("username", username);
        options.put("email", email);
        options.put("phoneNumber", phoneNumber);
        options.put("address", address);
        options.put("qualification", qualification);
        options.put("skills", skills);
        options.put("experience", experience);

        Log.i("baseUrl",""+baseUrl);

        Call<List<JobFeed>> signinservice = webApiInterface.getJobs(
                "anyyyy",
                "email",
                "1234567890",
                "btwon",
                "btech",
                "skills",
                "experience"
        );

       // Call<JobFeed> signinservice = webApiInterface.getJobs(options);

        signinservice.enqueue(new Callback<List<JobFeed>>() {
            @Override
            public void onResponse(Call<List<JobFeed>> call, Response<List<JobFeed>> response) {
                // showToast("User not found!");

                if (response.isSuccessful()) {

                    List<JobFeed> jobs = response.body();




                    if (callback != null) {
                        callback.onJobFeedReceived(jobs);
                    }



                } else {
                    // Handle unsuccessful response
                }


            }

            @Override
            public void onFailure(Call<List<JobFeed>> call, Throwable t) {
                showToast("Not Working");
            }
        });




    }




    private void showToast(String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
