package com.example.hustle4work.utility;

public class Constant {

    public static String TOKEN ="token";
}
