package com.example.hustle4work.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hustle4work.R;
import com.example.hustle4work.utility.WebApiCall;

public class SignUpActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editEmail;
    private EditText editTxtpasswd;
    private EditText editTxtconfirmpasswd;
    private EditText editTxtphoneno;
    private EditText editTxtaddress;

    private TextView txtlogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        editTextUsername = findViewById(R.id.editUser);
        editEmail = findViewById(R.id.editEmail);
        editTxtpasswd = findViewById(R.id.editpasswd);
        editTxtconfirmpasswd = findViewById(R.id.editcnfmpasswd);
        editTxtphoneno = findViewById(R.id.editphone);
        editTxtaddress = findViewById(R.id.editaddress);
        txtlogin=  findViewById(R.id.txtSignUp);

        TextView btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateFields();
            }
        });

        txtlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(i);
            }
        });

    }
    private void validateFields() {
        boolean isValid = true;

        String username = editTextUsername.getText().toString();
        String email = editEmail.getText().toString();
        String password = editTxtpasswd.getText().toString();
        String confirmPassword = editTxtconfirmpasswd.getText().toString();
        String phoneNumber = editTxtphoneno.getText().toString();
        String address = editTxtaddress.getText().toString();

        if (username.isEmpty()) {
            showToast("Username is required");
            isValid = false;
        }

        if (email.isEmpty()) {
            showToast("Email is required");
            isValid = false;
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showToast("Invalid email format");
            isValid = false;
        }

        if (password.isEmpty()) {
            showToast("Password is required");
            isValid = false;
        }

        if (confirmPassword.isEmpty()) {
            showToast("Confirm password is required");
            isValid = false;
        } else if (!confirmPassword.equals(password)) {
            showToast("Passwords do not match");
            isValid = false;
        }

        if (phoneNumber.isEmpty()) {
            showToast("Phone number is required");
            isValid = false;
        }

        if (address.isEmpty()) {
            showToast("Address is required");
            isValid = false;
        }

        if (isValid) {
            callSignupApi(username, email, password, phoneNumber, address);

        }
    }

    private void callSignupApi(String username, String email, String password, String phoneNumber, String address) {

            WebApiCall webApiCall = new WebApiCall(SignUpActivity.this);
            webApiCall.registerUser(username, email, password, phoneNumber, address);


    }

    private void showToast(String message) {
        Toast.makeText(SignUpActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}