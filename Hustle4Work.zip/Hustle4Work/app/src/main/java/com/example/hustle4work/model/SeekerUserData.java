package com.example.hustle4work.model;

public class SeekerUserData {



}
