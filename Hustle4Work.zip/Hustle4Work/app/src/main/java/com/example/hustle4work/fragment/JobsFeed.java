package com.example.hustle4work.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.hustle4work.Interface.JobFeedCallback;
import com.example.hustle4work.R;
import com.example.hustle4work.activity.SignUpActivity;
import com.example.hustle4work.adapter.jobAdapter;
import com.example.hustle4work.model.JobFeed;
import com.example.hustle4work.utility.WebApiCall;

import java.util.List;

public class JobsFeed extends Fragment  implements JobFeedCallback {


     View view;
    RecyclerView recyclerView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_jobs_feed, container, false);

         recyclerView = view.findViewById(R.id.recycler_view);




        // Set a layout manager (e.g., LinearLayoutManager or GridLayoutManager)
       // recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));




       /* recyclerView.setItemAnimator(new DefaultItemAnimator());
        // Create and set the adapter
        jobAdapter adapter = new jobAdapter(this);
        recyclerView.setAdapter(adapter);*/
       /* {
            "username" : "anyyyy",
                "email" : "email",
                "phoneNumber" : "1234567890",
                "address" : "btwon",
                "qualification" : "btech",
                "skills" : "skills",
                "experience" : "experience"
        }*/


        callSJobFeedApi("anyyyy","email","1234567890","btwon","btech","skills","experience");
        return  view;
    }

    private void callSJobFeedApi(String username, String email, String phoneNumber, String address, String qualification,String skills,String experience) {

        WebApiCall webApiCall = new WebApiCall(getActivity());
        webApiCall.getjobFeed(username, email, phoneNumber, address, qualification , skills , experience,this);


    }

    @Override
    public void onJobFeedReceived(List<JobFeed> jobFeedList) {
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        // Create and set the adapter
        jobAdapter adapter = new jobAdapter(getActivity(),jobFeedList);
        recyclerView.setAdapter(adapter);

    }
}